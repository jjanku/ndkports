/*
 * This file exists solely to keep VC++ happy
 * because it doesn't provide a <unistd.h>
 * and flex doesn't provide us with any way to
 * prevent the inclusion of it.
 */